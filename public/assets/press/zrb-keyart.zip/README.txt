ZOMBIE REALITY BREACH - PRESS KIT
KaMa Studios - https://zombierealitybreach.com - support@zombierealitybreach.com
TikTok https://www.tiktok.com/@zombierealitybreach - Instagram https://www.instagram.com/zombierealitybreach/
YouTube https://www.youtube.com/@ZombieRealityBreach

Logo/        Logo (ZOMBIE lettering + REALITY BREACH), wordmark, skull signet, app icon.
             *_on_dark for dark backgrounds, *_on_light for light backgrounds. SVG scales freely.
             Do not stretch, rotate, recolour or add effects. Keep clear space around it.
KeyArt/      Five key art themes: 16:9 with and without logo, 7:10 portrait, 1:1 square, 10:3 hero.

Press and content creators may use this material for reporting, videos and streams.
Monetised let's plays are welcome. Please credit "Zombie Reality Breach by KaMa Studios".